/********************************************************************************
  Authors: Carlos Segura, Emmanuel Romero Ruíz, Gabriel Tadeo Vazquez Ballesteros 
	and Mario Guzman Silverio

	Description: utils for generating random numbers
********************************************************************************/


int getRandomInteger0_N(int n);//get random integer [0, n]
double generateRandomDouble0_Max(double maxValue);//get random double [0, maxValue]
