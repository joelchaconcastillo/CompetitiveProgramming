/********************************************************************************
  Authors: Carlos Segura, Emmanuel Romero Ruíz, Gabriel Tadeo Vazquez Ballesteros 
	and Mario Guzman Silverio

	Description: some crossovers were tested with no success, so the algorithm
	does not use crossover.
********************************************************************************/


#include "Individual.h"

void Individual::crossover(Individual &ind) {
}
